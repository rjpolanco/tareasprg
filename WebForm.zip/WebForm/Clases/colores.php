<?php




class colores extends Conectar{
    public function select_colores() {
    $sql = "SELECT * FROM colores";
    $conx = parent::conexion();
    $stm = $conx->prepare($sql);
    $stm ->execute();
    $data = $stm->fetchAll(PDO::FETCH_ASSOC);
    return $data;
    
    

}
  
    
}