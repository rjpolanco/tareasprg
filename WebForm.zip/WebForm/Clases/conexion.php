<?php

class Conectar{
    public static function conexion(){
               
        try{
            $conexion = new PDO('mysql: host=localhost; dbname=traductor; port=3306', 'root', '');
            
            $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $conexion->query("SET NAMES 'utf8'");
            
        } catch (PDOException $ex) {
            echo "Sucedio un problema al realizar la conexión";
            echo $ex;
        }
        
        
        return $conexion;
        
    }
}