

<?php

require_once '\xampp\htdocs\WebForm\index.php';

$r= $_POST['select1'];

if($r=="Amarillo"){
    echo "Yelow";
}if($r=="Verde"){
    echo "Green";
}if($r=="Azul"){
    echo "Blue";
}if($r=="Morado"){
    echo "Morado";
}if($r=="Rojo"){
    echo "Red";
}if($r=="Anaranjado"){
    echo "Orange";
}if($r=="Rosado"){
    echo "Pink";
}if($r=="Café"){
    echo "Brown";
}if($r=="Celeste"){
    echo "Light-Blue";
}if($r=="Magenta"){
    echo "Magenta";
}








    
 