<?php
require_once 'clases/conexion.php';
require_once 'clases/colores.php';


$i=0;
$colores = new colores();
$data = $colores->select_colores();


 /*           foreach($data as $value){
                    echo $data [$i] ['espanol'];
                    $i++;
                }


/*print_r($data);*/

?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!doctype html>
<html lang="es">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="Clases/style.css" rel="stylesheet" type="text/css"/>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">

    <title>Ejercicio PRG4</title>
  </head>
  <body>
      <h1>Ejercicio de traductor</h1>
    
    
      <div class="container-fluid">
      
          <label>Seleccione el color</label>
          <form method="post" action="clases/ingles.php">
              
         
              <select id="select1" name="select1">
                <option><?php echo $data [0]['espanol']; $i++?></option>
                <option><?php echo $data [1]['espanol']; $i++?></option>
                <option><?php echo $data [2]['espanol']; $i++?></option>
                <option><?php echo $data [3]['espanol']; $i++?></option>
                <option><?php echo $data [4]['espanol']; $i++?></option>
                <option><?php echo $data [5]['espanol']; $i++?></option>
                <option><?php echo $data [6]['espanol']; $i++?></option>
                <option><?php echo $data [7]['espanol']; $i++?></option>
                <option><?php echo $data [8]['espanol']; $i++?></option>
                <option><?php echo $data [9]['espanol']; $i++?></option>

            </select>
            <div>
            <br>    
            <input type="submit" name="btntraduce"value="Traducir">
            <?php $i=0;?>  
            
              
       </div> 
          </form>
 
    </div>
      
      

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"  crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"  crossorigin="anonymous"></script>
  </body>
</html>
